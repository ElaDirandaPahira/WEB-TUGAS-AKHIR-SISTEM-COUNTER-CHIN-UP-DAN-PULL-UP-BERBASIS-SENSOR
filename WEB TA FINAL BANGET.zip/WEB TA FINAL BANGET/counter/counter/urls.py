from django.contrib import admin
from django.urls import path, include
from counterchinuppullup import views  # Pastikan Anda mengimpor views dari counterchinuppullup

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),  # Menambahkan root URL
    path('connect_ble/', views.connect_ble_view, name='connect_ble'),
    path('home/', views.home, name='home'),
    path('mode/', views.mode, name='mode'),
    path('get_counter/', views.get_counter, name='get_counter'),
    path('select_mode/', views.select_mode, name='select_mode'),
    path('send_start_command/', views.send_start_command, name='send_start_command'),
    path('send_restart_command/', views.send_restart_command, name='send_restart_command'),
    path('reset_counter/', views.reset_counter, name='reset_counter'),  # Tambahkan ini
]
