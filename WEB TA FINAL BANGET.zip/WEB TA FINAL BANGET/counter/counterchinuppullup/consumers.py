import json
from channels.generic.websocket import WebsocketConsumer
from asgiref.sync import async_to_sync

class CountConsumer(WebsocketConsumer):
    def connect(self):
        self.accept()

    def disconnect(self, close_code):
        pass

    def receive(self, text_data):
        data = json.loads(text_data)
        mode = data.get('mode')
        count = data.get('count')
        not_count = data.get('not_count')

        # Kirim data ke frontend
        self.send(text_data=json.dumps({
            'mode': mode,
            'count': count,
            'not_count': not_count
        }))
