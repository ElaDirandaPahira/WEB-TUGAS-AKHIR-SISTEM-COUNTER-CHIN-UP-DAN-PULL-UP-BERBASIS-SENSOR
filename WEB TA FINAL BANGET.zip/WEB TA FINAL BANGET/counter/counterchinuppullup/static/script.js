// Fungsi untuk pergi ke halaman beranda dengan URL yang ditentukan
function goToHomePage(page) {
  window.location.href = page;
}

// // Memeriksa apakah ada parameter mode di URL saat halaman dimuat
// window.onload = function() {
//   const urlParams = new URLSearchParams(window.location.search);
//   const mode = urlParams.get('mode');
//   if (mode) {
//     document.getElementById('mode-title').textContent = 'Mode ' + mode;
//   }
// }

