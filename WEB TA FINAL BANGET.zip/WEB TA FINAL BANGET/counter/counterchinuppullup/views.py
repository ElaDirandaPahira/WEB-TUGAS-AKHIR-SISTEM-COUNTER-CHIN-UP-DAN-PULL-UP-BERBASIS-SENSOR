from django.shortcuts import render, redirect
from django.http import JsonResponse
import asyncio
from bleak import BleakClient
from asgiref.sync import sync_to_async

# Variabel global
client = None  # Variabel untuk menyimpan koneksi BleakClient
loop = asyncio.get_event_loop()
count = 0
not_count = 0

async def connect_ble():
    global client
    if client is None:
        client = BleakClient("E8:6B:EA:DF:B4:EE")
        await client.connect()
    return client.is_connected

async def send_command(command):
    global client
    if client is not None and client.is_connected:
        await client.write_gatt_char("6e400002-b5a3-f393-e0a9-e50e24dcca9e", command.encode('utf-8'))

async def receive_data():
    global client, count, not_count
    if client is not None and client.is_connected:
        value = await client.read_gatt_char("beb5483e-36e1-4688-b7f5-ea07361b26a8")
        if value:
            received_data = value.decode('utf-8', errors='ignore')  # Handle any decoding issues
            if ':' in received_data:
                count, not_count = map(int, received_data.split(':'))
            elif received_data.isdigit():
                count = int(received_data)
    return {'count': count, 'not_count': not_count}

@sync_to_async
def sync_connect_ble():
    return asyncio.run(connect_ble())

@sync_to_async
def sync_send_command(command):
    return asyncio.run(send_command(command))

@sync_to_async
def sync_receive_data():
    return asyncio.run(receive_data())

def home(request):
    mode = request.session.get('selected_mode', 'pushup')
    if mode == 'pullup':
        return render(request, 'pullup.html')
    elif mode == 'chinup':
        return render(request, 'chinup.html')
    return render(request, 'home.html')

def mode(request):
    return render(request, 'mode.html')

def connect_ble_view(request):
    if request.method == 'GET' and 'start' in request.GET:
        connected = loop.run_until_complete(sync_connect_ble())
        connected = bool(connected)
        request.session['ble_connected'] = connected
        return JsonResponse({'connected': connected})
    return render(request, 'connect_ble.html')

def get_counter(request):
    data = loop.run_until_complete(sync_receive_data())
    return JsonResponse(data)

def select_mode(request):
    if request.method == 'POST':
        mode = request.POST.get('mode')
        if mode:
            request.session['selected_mode'] = 'pullup' if mode == '1' else 'chinup'
            loop.run_until_complete(sync_send_command(mode))
            return JsonResponse({'success': True})
    return JsonResponse({'success': False})

def send_start_command(request):
    if request.method == 'POST':
        loop.run_until_complete(sync_send_command("START"))
        return JsonResponse({'success': True})
    return JsonResponse({'success': False})

def send_restart_command(request):
    if request.method == 'POST':
        mode = request.session.get('selected_mode', 'pushup')
        if mode == 'pullup':
            loop.run_until_complete(sync_send_command("1"))
        elif mode == 'chinup':
            loop.run_until_complete(sync_send_command("2"))
        return JsonResponse({'success': True})
    return JsonResponse({'success': False})

def reset_counter(request):
    global count, not_count
    if request.method == 'POST':
        count = 0
        not_count = 0
        return JsonResponse({'success': True})
    return JsonResponse({'success': False})
